<?php
// ПриводБаза — обработчик форм с защитой от спама

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); exit;
}

function clean($str) {
    return htmlspecialchars(strip_tags(trim($str)), ENT_QUOTES, 'UTF-8');
}

$page    = clean($_POST['page'] ?? '');
$is_kontakty = strpos($page, 'kontakty') !== false;
$ok_url  = $is_kontakty ? '/kontakty/?sent=1'  : '/consult/?sent=1';
$fail_url= $is_kontakty ? '/kontakty/?error=1' : '/consult/?error=1';
$spam_url= '/';  // спамеров молча редиректим на главную

// ── ЗАЩИТА 1: Honeypot ──────────────────
// Боты заполняют все поля, люди это поле не видят
if (!empty($_POST['website'])) {
    header('Location: ' . $spam_url); exit;
}

// ── ЗАЩИТА 2: Время заполнения формы ────
// Форма должна быть заполнена минимум за 3 секунды
$form_time = intval($_POST['form_time'] ?? 0);
$now = time();
if ($form_time === 0 || ($now - $form_time) < 3) {
    header('Location: ' . $spam_url); exit;
}
// И не более 2 часов (протухший токен)
if (($now - $form_time) > 7200) {
    header('Location: ' . $fail_url); exit;
}

// ── ЗАЩИТА 3: Проверка referer ──────────
$referer = $_SERVER['HTTP_REFERER'] ?? '';
$host = parse_url($referer, PHP_URL_HOST);
if (!in_array($host, ['privodbase.ru', 'www.privodbase.ru'])) {
    header('Location: ' . $spam_url); exit;
}

// ── ЗАЩИТА 4: Rate limiting по IP ───────
$ip = $_SERVER['REMOTE_ADDR'] ?? '';
$ip_file = sys_get_temp_dir() . '/pb_' . md5($ip) . '.txt';
if (file_exists($ip_file)) {
    $last = intval(file_get_contents($ip_file));
    if (($now - $last) < 60) {
        // Не чаще 1 раза в минуту с одного IP
        header('Location: ' . $spam_url); exit;
    }
}
file_put_contents($ip_file, $now);

// ── ПОЛУЧАЕМ ДАННЫЕ ─────────────────────
$name    = clean($_POST['name'] ?? '');
$email   = clean($_POST['email'] ?? '');
$type    = clean($_POST['type'] ?? '');
$message = clean($_POST['msg'] ?? $_POST['message'] ?? '');
$subject_input = clean($_POST['subject'] ?? '');

// ── ВАЛИДАЦИЯ ────────────────────────────
if (empty($email) || empty($message)) {
    header('Location: ' . $fail_url); exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header('Location: ' . $fail_url); exit;
}
if (strlen($message) < 5 || strlen($message) > 5000) {
    header('Location: ' . $fail_url); exit;
}

// Проверка на спам-слова в сообщении
$spam_words = ['viagra', 'casino', 'bitcoin', 'crypto', 'click here', 'buy now', 'http://', 'https://', '.xyz', '.top'];
$msg_lower = strtolower($message . ' ' . $name);
foreach ($spam_words as $word) {
    if (strpos($msg_lower, $word) !== false) {
        header('Location: ' . $spam_url); exit;
    }
}

// ── ФОРМИРУЕМ ПИСЬМО ─────────────────────
$types = [
    'alarm'   => 'Ошибка / alarm-код',
    'analog'  => 'Подбор аналога / импортозамещение',
    'select'  => 'Подбор оборудования',
    'compat'  => 'Вопрос совместимости',
    'tech'    => 'Технический вопрос',
    'add'     => 'Дополнение к базе',
    'error'   => 'Нашёл ошибку в информации',
    'partner' => 'Сотрудничество',
    'other'   => 'Другое',
];
$type_label = $types[$type] ?? ($type ?: 'Не указан');

$subject_text = 'ПриводБаза: ' . $type_label;
if ($subject_input) $subject_text .= ' — ' . $subject_input;

$body  = "Новая заявка с сайта privodbase.ru\n\n";
$body .= "Имя:      " . ($name ?: 'Не указано') . "\n";
$body .= "Email:    " . $email . "\n";
$body .= "Тип:      " . $type_label . "\n";
if ($subject_input) $body .= "Тема:     " . $subject_input . "\n";
$body .= "Страница: " . $page . "\n\n";
$body .= "Сообщение:\n" . str_repeat('-', 40) . "\n";
$body .= $message . "\n";
$body .= str_repeat('-', 40) . "\n\n";
$body .= "IP:    " . $ip . "\n";
$body .= "Время: " . date('d.m.Y H:i') . " МСК\n";
$body .= "Ответить: " . $email . "\n";

$to      = 'info@privodbase.ru';
$subject = '=?UTF-8?B?' . base64_encode($subject_text) . '?=';
$headers  = "From: noreply@privodbase.ru\r\n";
$headers .= "Reply-To: " . $email . "\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
$headers .= "Content-Transfer-Encoding: 8bit\r\n";

$sent = mail($to, $subject, $body, $headers);
header('Location: ' . ($sent ? $ok_url : $fail_url));
exit;
?>
